//Bolts fired by the enemy
/*
1) Normal : 80% chance, red, 10 attack damage without energy drink, 8 with energy drink, and does 1 attack
2) Boss : 20% chance, purple, 20 attack damage without energy drink, 16 with energy drink, and does 3 attacks 
*/ 

class Bolts{
    constructor(){
        
    }
}