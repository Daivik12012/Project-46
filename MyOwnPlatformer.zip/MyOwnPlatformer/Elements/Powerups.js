// Powerups to help the player
/*
1) Apple : will give shield that will last 6 attacks.
2) Orange : will give jump boost.
3) Grape : speed boost.
4) Energy drink : jump and speed boosts and 20% less attack damage. 
5) Shield : will give shield that will protect against 1 attack.
*/

class PowerUps{
    constructor(){

    }
}