class Platforms{
    constructor(){
        this.platform = createSprite(300,700,500,50);
        //this.platform.debug = true
    }
   

}