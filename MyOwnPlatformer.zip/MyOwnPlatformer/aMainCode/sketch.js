var player, game, platforms;
var runner;
var frameCount;

var runnerRun;
var runnerJump;

function preload(){
    runnerRun =  loadAnimation(
    "../sprites/7.png","../sprites/8.png","../sprites/9.png","../sprites/10.png","../sprites/11.png","../sprites/12.png")
    runnerJump = loadAnimation("../sprites/jumping1.png", "../sprites/jumping2.png", "../sprites/jumping3.png", "../sprites/jumping4.png",
    "../sprites/jumping5.png", "../sprites/jumping6.png", "../sprites/jumping7.png");
}

function setup(){
    createCanvas(windowWidth,windowHeight);
    game = new Game();
    game.start();
    //runner = player.runner;
}
function draw(){
    background(255);   
    game.display();
}

function keyPressed(){
    if (keyCode === 32) {
        //console.log(frameCount)
       game.play()   
    }    
}
