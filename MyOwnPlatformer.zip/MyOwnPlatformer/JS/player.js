class Player{
    constructor(){
       this.runner = createSprite(200,200,50,50);
       this.runner.addAnimation("runner",runnerRun);
       this.runner.addAnimation("jump",runnerJump);
       this.runner.scale = 2;
       this.runner.setCollider("rectangle", 0, 0, 20, 31);
       
       //this.runner.debug = true
        
    }
    
}   