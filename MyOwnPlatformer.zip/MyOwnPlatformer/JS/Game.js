class Game{
    constructor(){
        
    }

    start(){
        player = new Player();
        platforms = new Platforms();   
    }   

    play(){    
            player.runner.velocityY = -10;
            player.runner.changeAnimation("jump",runnerJump);        
            player.runner.scale = 2;       
           
    }

    display(){
        player.runner.velocityY +=0.5;
        player.runner.collide(platforms.platform)
        drawSprites();
    }
}